/* global QUnit */

sap.ui.require(["com/skysinc/frota/frota/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
