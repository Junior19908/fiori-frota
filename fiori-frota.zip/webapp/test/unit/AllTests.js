sap.ui.define([
	"com/skysinc/frota/frota/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
